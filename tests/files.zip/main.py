import time
import numpy as np

from core.universe import Universe
from core.attention import AttentionField


def main():
    print("=== CIMA0 Phase8.1 Reference (locked core + rumor-spreading attention) ===")

    u = Universe(n=4096)
    attn = AttentionField(max_queue=256, propagate_prob=0.15, min_delay=200)

    TOTAL = 2_000_000
    REPORT_EVERY = 200_000
    refined_total = 0

    for t in range(TOTAL):
        idx = u.event()
        attn.observe_after_step(u, idx)

        # Compute 层每隔一小段就来处理一批已经延迟满足的任务
        # (这里只做统计示意，真正的"精算"逻辑留给 compute 层实现)
        if t % 50 == 0:
            ready = attn.pop_ready(u.time, k=8)
            refined_total += len(ready)

        if t % REPORT_EVERY == 0:
            xs = np.array([c.x for c in u.cells])
            print({
                "time": u.time,
                "x_std": round(float(xs.std()), 5),
                "queue_len": len(attn.pending),
                "max_touch_per_call": attn.max_touch_per_call,
                "refined_total": refined_total,
            })

    print("finished")


if __name__ == "__main__":
    main()
