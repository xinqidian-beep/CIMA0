import numpy as np


class Cell:
    """
    最小生命单元。

    元神(不可变核心)：
        omega —— 一旦初始化，任何外部代码都无法修改。
        内部规则(-omega^2 * x 恢复力) —— 永远存在，永远生效。

    幻境层(可以随时间生灭)：
        x, v —— 状态，随事件不断变化。
        activity_ema —— 自己对自己历史波动幅度的记忆，仅用于局部举手判断，
                         不参与动力学计算，不影响 force。

    唯一允许外部影响的入口：step() 的 perturb 参数。
    perturb 只能进入 force 的加法项，不能修改 omega、不能修改内部规则本身。
    """

    __slots__ = ("_x", "_v", "_omega", "activity_ema", "last_seen_x", "last_delta")

    def __init__(self, x, v, omega):
        self._x = x
        self._v = v
        self._omega = omega
        self.activity_ema = 0.0   # 历史平均变化幅度（背景水平）
        self.last_seen_x = x
        self.last_delta = 0.0     # 这一次 step 的瞬时变化幅度

    @property
    def x(self):
        return self._x

    @property
    def v(self):
        return self._v

    @property
    def omega(self):
        return self._omega

    def energy(self):
        return 0.5 * (self._v * self._v + self._omega * self._omega * self._x * self._x)

    def step(self, coupling=0.0, perturb=0.0, dt=0.01):
        """
        半隐式欧拉。coupling 来自邻居局部耦合力，perturb 来自外部扰动(经过延迟/衰减处理过的)。
        两者都只是 force 的加法项，omega 和 -omega^2*x 这条规则本身永远不变。
        """
        force = -self._omega * self._omega * self._x + coupling + perturb
        self._v = self._v + force * dt
        self._x = self._x + self._v * dt

        # 局部举手判断用的自我记忆：只依赖自己的历史，不读任何其他 cell
        self.last_delta = abs(self._x - self.last_seen_x)
        self.last_seen_x = self._x
        # ema 用较长的时间常数跟踪"背景水平"，不包含这一步本身，避免自己和自己比
        self.activity_ema = 0.995 * self.activity_ema + 0.005 * self.last_delta

    def local_threshold(self):
        # 阈值 = 背景水平的若干倍，是"这一步是否明显异于我平时的样子"，不是自己和自己比
        return max(self.activity_ema * 3.0, 1e-5)

    def is_flaring(self):
        # 瞬时变化量是否显著超过自己的历史背景水平（二元判断，不是打分排序）
        return self.last_delta > self.local_threshold()
